//
//  PeliculasViewModel.swift
//  MovieApp
//
//  Created by MAC on 20/11/26.
//


import Foundation
import Observation


@Observable
class PeliculasViewModel {
    var peliculas: [Pelicula] = []
    
    init () {
        cargarPeliculas()
    }
    
    func cargarPeliculas() {
        peliculas = [
            Pelicula(id: 1, titulo: "Project Hail Marry", anio: 2026,
                     duracionMin: 157, genero: "Sci-Fi/Adventure", director: "Phil Lord",
                     sinopsis: "guy does science with sun-eating bacteria",imagen: "poster2"),
            Pelicula(id: 2, titulo: "Barbie", anio: 2023,
                     duracionMin: 114, genero: "Comedy/Fantasy", director: "Greta Gerwig",
                     sinopsis: "barbie movie",imagen: "posterb"),
            Pelicula(id: 3, titulo: "Superman", anio: 2025,
                     duracionMin: 129, genero: "Action/Fantasy", director: "James Gunn",
                     sinopsis: "what was it again? it didn't have any cultural impact so i forgor", imagen: "posters"),
            Pelicula(id: 4, titulo: "Bee Movie", anio: 2007,
                     duracionMin: 91, genero: "Family", director: "Steve Hickner",
                     sinopsis: "bzzzzzzz bzzzzzz bzz bzzzzz bzzzzzz bzzz bzzzzz bzzzzzzz bzzzzzz bzz bzzzzz bzzzzzz bzzz bzzzzz bzzzzzzz bzzzzzz bzz bzzzzz bzzzzzz bzzz bzzzzz bzzzzzzz bzzzzzz bzz bzzzzz bzzzzzz bzzz bzzzzz", imagen: "posterbee"),
        ]
    }
    
    
}


