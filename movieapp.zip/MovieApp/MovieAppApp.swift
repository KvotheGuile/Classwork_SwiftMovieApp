//
//  MovieAppApp.swift
//  MovieApp
//
//  Created by MAC on 20/11/26.
//

import SwiftUI

@main
struct MovieAppApp: App {
    var body: some Scene {
        WindowGroup {
            PeliculasView()
        }
    }
}
